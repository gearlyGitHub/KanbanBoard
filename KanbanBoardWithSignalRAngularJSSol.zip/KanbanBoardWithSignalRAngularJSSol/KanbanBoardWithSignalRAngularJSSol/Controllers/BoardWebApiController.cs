﻿using KanbanBoardWithSignalRAngularJSSol.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
//  D.Parker is a fart head.
//  G.Early is a tomato brain.

namespace KanbanBoardWithSignalRAngularJSSol.Controllers
{
    [RoutePrefix("api/BoardWebApi")]
    public class BoardWebApiController : ApiController
    {
        [HttpGet]
        public HttpResponseMessage Get()
        {
            var repo = new BoardRepository();
            var response = Request.CreateResponse();

            response.Content = new StringContent(JsonConvert.SerializeObject(repo.GetColumns()));
            response.StatusCode = HttpStatusCode.OK;

            return response;
        }

        [HttpGet]
        public HttpResponseMessage CanMove(int sourceColId, int targetColId)
        {            
            var response = Request.CreateResponse();
            response.StatusCode = HttpStatusCode.OK;

            if (targetColId == 1) // TODO column
                response.Content = new StringContent(JsonConvert.SerializeObject(new
                {
                    canMove = false,
                    Message = "Can't move back to TODO"
                }));
            else if (sourceColId == 5) // DONE column
                response.Content = new StringContent(JsonConvert.SerializeObject(new
                {
                    canMove = false,
                    Message = "Can't move away from DONE"
                }));
            else if (sourceColId == targetColId)
                response.Content = new StringContent(
                    JsonConvert.SerializeObject(new
                    {
                        canMove = false,
                        Message = "Can't move a task to its current column"
                    }));
            else if (sourceColId < (targetColId - 1) || sourceColId > (targetColId + 1))
                response.Content = new StringContent(
                    JsonConvert.SerializeObject(new
                    {
                        canMove = false,
                        Message = "Can't move more than one column away"
                    }));
            else
                response.Content = new StringContent(
                    JsonConvert.SerializeObject(new
                    {
                        canMove = true
                    }));
            

            return response;
        }

        [HttpGet, Route("EditTask")]
        public HttpResponseMessage EditTask(int taskId, string paramNames, string paramValues)
        {
            (new BoardRepository()).EditTask(taskId, paramNames.Split('|'), paramValues.Split('|'));

            return Request.CreateResponse(HttpStatusCode.OK);
        }

        [HttpGet, Route("CreateTask")]
        public HttpResponseMessage CreateTask(string paramNames, string paramValues)
        {
            (new BoardRepository()).CreateTask(paramNames.Split('|'), paramValues.Split('|'));

            return Request.CreateResponse(HttpStatusCode.OK);
        }

        [HttpPost]       
        public HttpResponseMessage MoveTask(JObject moveTaskParams)
        {
            dynamic json = moveTaskParams;
            var repo = new BoardRepository();
            repo.MoveTask((int)json.taskId, (int)json.targetColId);
                       
            var response = Request.CreateResponse();
            response.StatusCode = HttpStatusCode.OK;

            return response;
        }
    }
}
