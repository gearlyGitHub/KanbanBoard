﻿sulhome.kanbanBoardApp.controller('boardCtrl', function ($scope, boardService) {
    // Model
    $scope.columns = [];
    $scope.isLoading = false;
    $scope.editTaskNum = -1;
    $scope.showCreateForm = false;

    $scope.toggleEditForm = function (taskId) {
        if ($scope.editTaskNum != taskId) {
            if ($scope.editTaskNum != -1)
                document.getElementById("editTask" + $scope.editTaskNum).innerText = "Show edit form";
            $scope.editTaskNum = taskId;
            document.getElementById("editTask" + taskId).innerText = "Hide edit form";
        }
        else {
            $scope.editTaskNum = -1;
            document.getElementById("editTask" + taskId).innerText = "Show edit form";
        }
    }

    $scope.toggleCreateTask = function () {
        $scope.showCreateForm = !($scope.showCreateForm);
    }

    $scope.createNewTask = function () {
        var paramNames = "name|description|assignee";
        var paramValues = document.getElementById("createTaskName").value + '|'
            + document.getElementById("createTaskDescription").value + '|' +
            document.getElementById("createTaskAssignee").value;
        boardService.createTask(paramNames, paramValues);
        $scope.refreshBoard();
        document.getElementById("createTaskName").value = "Name";
        document.getElementById("createTaskDescription").value = "Description";
        document.getElementById("createTaskAssignee").value = "Assignee"
        $scope.showCreateForm = false;
        $scope.editTaskNum = -1;
    }

    function init() {
        $scope.isLoading = true;
        boardService.initialize().then(function (data) {
            $scope.isLoading = false;
            $scope.refreshBoard();
        }, onError);
        $scope.editTaskNum = -1;
        $scope.createTask = false;
    };

    $scope.editClick = function (taskId, fieldName, currentValue) {
        var result = prompt('New ' + fieldName + ':', currentValue);
        if (result) {
            if (result.trim().length > 0)
                performEdit(taskId, fieldName, result);
            else
                toastr.error('New value can\'t be blank!', 'Edit failed');
        }
        else {
            toastr.warning('Edit canceled.');
        }
    }
    var performEdit = function (taskId, paramNames, paramValues) {
        boardService.editTask(taskId, paramNames, paramValues)
            .then(function (editTaskResponse) {
                $scope.isLoading = false;
                if (editTaskResponse == true) {
                    boardService.sendRequest();
                    $scope.editTaskNum = -1;
                }
                else
                    toastr.warning('Edit failed.', 'Failure');
                $scope.refreshBoard();
            }, onError);
    }

    $scope.editButtonClick = function (taskId) {
        var paramNames = 'name|description|assignee';
        var paramValues = document.getElementById("editTask" + taskId + "Name").value + '|'
            + document.getElementById("editTask" + taskId + "Description").value + '|'
            + document.getElementById("editTask" + taskId + "Assignee").value;
        //alert(paramNames + '\n' + paramValues);
        performEdit(taskId, paramNames, paramValues);
        $scope.refreshBoard();
    }

    $scope.refreshBoard = function refreshBoard() {        
        $scope.isLoading = true;
        boardService.getColumns()
           .then(function (data) {               
               $scope.isLoading = false;
               $scope.columns = data;
           }, onError);
    };    

    $scope.onDrop = function (data, targetColId) {
        boardService.canMoveTask(data.ColumnId, targetColId)
            .then(function (canMoveData) {
                if (canMoveData.canMove) {
                    boardService.moveTask(data.Id, targetColId).then(function (taskMoved) {
                        $scope.isLoading = false;                        
                        boardService.sendRequest();
                    }, onError);
                    $scope.isLoading = true;
                }
                else {
                    $scope.isLoading = false;
                    toastr.warning(canMoveData.Message, 'Failure');
                }
            }, onError);
    };

    // Listen to the 'refreshBoard' event and refresh the board as a result
    $scope.$parent.$on("refreshBoard", function (e) {
        $scope.refreshBoard();
        toastr.success("Board updated successfully", "Success");
    });

    var onError = function (errorMessage) {
        $scope.isLoading = false;
        toastr.error(errorMessage, "Error");
    };

    init();
});