﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KanbanBoardWithSignalRAngularJSSol.Models
{
    using static Array;
    public class Task
    {
        private static string[] FieldNames =
        {
            "id",
            "assignee",
            "name",
            "description",
            "columnid"
        };
        public object this[string key]
        {
            set
            {
                if (key == "id")
                    Id = (int)value;
                else if (key == "assignee")
                    Assignee = (string)value;
                else if (key == "name")
                    Name = (string)value;
                else if (key == "description")
                    Description = (string)value;
                else if (key == "columnid")
                    ColumnId = (int)value;
            }
        }
        public int Id { get; set; }
        public string Assignee { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int ColumnId { get; set; }

        public void Edit(string[] paramNames, object[] paramValues)
        {
            foreach (string fn in FieldNames)
            {
                int index = FindIndex(paramNames, s => s.Equals(fn, StringComparison.CurrentCultureIgnoreCase));
                if (index > -1)
                {
                    this[fn.ToLower()] = paramValues[index];
                }
            }
        }
    }
}